#include "TransactionBuilder.h"

TransactionBuilder::TransactionBuilder(std::wstring jsonlPath)
    : path_(std::move(jsonlPath)) {}

TransactionBuilder::~TransactionBuilder() {
    Stop();
}

void TransactionBuilder::Start() {
    std::lock_guard<std::mutex> lock(mutex_);
    out_.open(path_, std::ios::out | std::ios::trunc | std::ios::binary);
    if (out_.is_open()) {
        // UTF-8 BOM，便于记事本打开
        static const unsigned char bom[] = {0xEF, 0xBB, 0xBF};
        out_.write(reinterpret_cast<const char*>(bom), 3);
        out_.flush();
    }
    nextId_ = 1;
    open_ = false;
    steps_.clear();
}

void TransactionBuilder::Stop() {
    std::lock_guard<std::mutex> lock(mutex_);
    if (open_) {
        // 内联关闭，避免重入锁
        std::uint64_t endMs = tLast_;
        std::string line = "{\"id\":";
        line += std::to_string(id_);
        line += ",\"t_start_ms\":";
        line += std::to_string(tStart_);
        line += ",\"t_end_ms\":";
        line += std::to_string(endMs);
        line += ",\"steps\":[";
        for (size_t i = 0; i < steps_.size(); ++i) {
            if (i) line += ',';
            line += "{\"name\":\"";
            line += Escape(steps_[i].name);
            line += "\",\"t\":";
            line += std::to_string(steps_[i].t_ms);
            if (!steps_[i].propsJson.empty()) {
                line += ',';
                line += steps_[i].propsJson;
            }
            line += '}';
        }
        line += "]}\n";
        if (out_.is_open()) {
            out_.write(line.data(), static_cast<std::streamsize>(line.size()));
            out_.flush();
        }
        open_ = false;
        steps_.clear();
    }
    if (out_.is_open()) {
        out_.flush();
        out_.close();
    }
}

std::string TransactionBuilder::Escape(const std::string& s) {
    std::string out;
    out.reserve(s.size() + 8);
    for (unsigned char c : s) {
        switch (c) {
            case '"': out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\n': out += ' '; break;
            case '\r': out += ' '; break;
            case '\t': out += ' '; break;
            default:
                if (c < 0x20) break;
                out.push_back(static_cast<char>(c));
                break;
        }
    }
    return out;
}

void TransactionBuilder::FlushLine(const std::string& line) {
    if (!out_.is_open() || line.empty()) return;
    out_.write(line.data(), static_cast<std::streamsize>(line.size()));
    out_.flush();
}

void TransactionBuilder::CloseOpen(std::uint64_t endMs) {
    if (!open_) return;

    std::string line = "{\"id\":";
    line += std::to_string(id_);
    line += ",\"t_start_ms\":";
    line += std::to_string(tStart_);
    line += ",\"t_end_ms\":";
    line += std::to_string(endMs);
    line += ",\"steps\":[";
    for (size_t i = 0; i < steps_.size(); ++i) {
        if (i) line += ',';
        line += "{\"name\":\"";
        line += Escape(steps_[i].name);
        line += "\",\"t\":";
        line += std::to_string(steps_[i].t_ms);
        if (!steps_[i].propsJson.empty()) {
            line += ',';
            line += steps_[i].propsJson;
        }
        line += '}';
    }
    line += "]}\n";
    FlushLine(line);

    open_ = false;
    steps_.clear();
}

void TransactionBuilder::OnStep(const Step& step, bool isStarter, bool isCloser) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!out_.is_open()) return;

    const std::uint64_t now = step.t_ms;

    if (open_) {
        if (now > tStart_ + kMaxMs || now > tLast_ + kIdleMs) {
            CloseOpen(tLast_);
        }
    }

    if (!open_) {
        if (!isStarter) {
            // 孤立的追加型事件：也开一个短事务，避免丢失
            if (step.name == "WindowActivated" || step.name == "KeyUp" ||
                step.name == "TabActive" || step.name == "NavCompleted") {
                // 仅导航完成单独成事务也有意义；Window/KeyUp 单独可忽略噪音
                if (step.name != "NavCompleted") return;
            }
        }
        open_ = true;
        id_ = nextId_++;
        tStart_ = now;
        tLast_ = now;
        steps_.clear();
        steps_.push_back(step);
        if (isCloser) {
            CloseOpen(now);
        }
        return;
    }

    steps_.push_back(step);
    tLast_ = now;
    if (isCloser) {
        CloseOpen(now);
    }
}

void TransactionBuilder::Poll(std::uint64_t nowMs) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!open_) return;
    if (nowMs > tStart_ + kMaxMs || nowMs > tLast_ + kIdleMs) {
        CloseOpen(tLast_);
    }
}
