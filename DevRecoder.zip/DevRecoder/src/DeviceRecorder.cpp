#include "DeviceRecorder.h"

#include <tlhelp32.h>

#include <cstring>
#include <vector>

DeviceRecorder* g_activeRecorder = nullptr;

namespace {

std::string WideToUtf8Trunc(const std::wstring& w, size_t maxBytes) {
    if (w.empty() || maxBytes == 0) return {};
    const int need = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), static_cast<int>(w.size()),
                                         nullptr, 0, nullptr, nullptr);
    std::string full(need, '\0');
    WideCharToMultiByte(CP_UTF8, 0, w.c_str(), static_cast<int>(w.size()),
                        full.data(), need, nullptr, nullptr);
    if (full.size() <= maxBytes) return full;

    size_t cut = maxBytes;
    while (cut > 0 && (static_cast<unsigned char>(full[cut]) & 0xC0) == 0x80) --cut;
    full.resize(cut);
    return full;
}

std::wstring ProcessFileName(DWORD pid) {
    HANDLE proc = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
    if (!proc) return L"";

    wchar_t path[MAX_PATH]{};
    DWORD size = MAX_PATH;
    std::wstring name;
    if (QueryFullProcessImageNameW(proc, 0, path, &size)) {
        const wchar_t* base = path;
        for (const wchar_t* p = path; *p; ++p) {
            if (*p == L'\\' || *p == L'/') base = p + 1;
        }
        name = base;
    }
    CloseHandle(proc);
    return name;
}

HWND ResolveInterestingHwnd(HWND hwnd) {
    if (!hwnd || !IsWindow(hwnd)) return nullptr;
    HWND root = GetAncestor(hwnd, GA_ROOT);
    if (!root) root = hwnd;
    if (!IsWindowVisible(root)) return nullptr;
    return root;
}

HWND WindowFromCursorDeep() {
    POINT pt{};
    if (!GetCursorPos(&pt)) return nullptr;

    HWND hwnd = WindowFromPoint(pt);
    if (!hwnd) return nullptr;

    HWND parent = hwnd;
    for (;;) {
        POINT client = pt;
        ScreenToClient(parent, &client);
        HWND child = RealChildWindowFromPoint(parent, client);
        if (!child || child == parent) break;
        parent = child;
    }
    return parent;
}

void AppendLenString(std::vector<char>& out, const std::string& s) {
    out.push_back(static_cast<char>(static_cast<std::uint8_t>(s.size())));
    out.insert(out.end(), s.begin(), s.end());
}

void AppendHwndPidProcTitle(std::vector<char>& out, HWND hwnd, bool includeTitle) {
    DWORD pid = 0;
    if (hwnd) GetWindowThreadProcessId(hwnd, &pid);

    wchar_t titleW[256]{};
    if (includeTitle && hwnd) GetWindowTextW(hwnd, titleW, 256);

    const std::string proc = WideToUtf8Trunc(ProcessFileName(pid), drb::kMaxProcBytes);
    const std::string title =
        includeTitle ? WideToUtf8Trunc(titleW, drb::kMaxTitleBytes) : std::string{};

    const std::uint64_t hwndVal = reinterpret_cast<std::uint64_t>(hwnd);
    const std::uint32_t pidVal = static_cast<std::uint32_t>(pid);
    out.insert(out.end(), reinterpret_cast<const char*>(&hwndVal),
               reinterpret_cast<const char*>(&hwndVal) + sizeof(hwndVal));
    out.insert(out.end(), reinterpret_cast<const char*>(&pidVal),
               reinterpret_cast<const char*>(&pidVal) + sizeof(pidVal));
    AppendLenString(out, proc);
    AppendLenString(out, title);
}

std::string JsonGetString(const std::string& json, const char* key) {
    const std::string pat = std::string("\"") + key + "\"";
    size_t pos = json.find(pat);
    if (pos == std::string::npos) return {};
    pos = json.find(':', pos + pat.size());
    if (pos == std::string::npos) return {};
    ++pos;
    while (pos < json.size() && (json[pos] == ' ' || json[pos] == '\t')) ++pos;
    if (pos >= json.size() || json[pos] != '"') return {};
    ++pos;
    std::string out;
    while (pos < json.size()) {
        const char c = json[pos++];
        if (c == '\\' && pos < json.size()) {
            const char n = json[pos++];
            if (n == '"' || n == '\\' || n == '/') out.push_back(n);
            else if (n == 'n' || n == 't') out.push_back(' ');
            else out.push_back(n);
            continue;
        }
        if (c == '"') break;
        if (c == '\n' || c == '\r') out.push_back(' ');
        else out.push_back(c);
    }
    return out;
}

int JsonGetInt(const std::string& json, const char* key, int defVal) {
    const std::string pat = std::string("\"") + key + "\"";
    size_t pos = json.find(pat);
    if (pos == std::string::npos) return defVal;
    pos = json.find(':', pos + pat.size());
    if (pos == std::string::npos) return defVal;
    ++pos;
    while (pos < json.size() && (json[pos] == ' ' || json[pos] == '\t')) ++pos;
    try {
        return std::stoi(json.substr(pos));
    } catch (...) {
        return defVal;
    }
}

std::string Utf8TruncBytes(std::string s, size_t maxBytes) {
    if (maxBytes == 0) return {};
    if (s.size() <= maxBytes) return s;
    size_t cut = maxBytes;
    while (cut > 0 && (static_cast<unsigned char>(s[cut]) & 0xC0) == 0x80) --cut;
    s.resize(cut);
    return s;
}

std::string ShortenUrl(std::string url) {
    const size_t q = url.find('?');
    if (q != std::string::npos) url.resize(q);
    const size_t h = url.find('#');
    if (h != std::string::npos) url.resize(h);
    return Utf8TruncBytes(std::move(url), drb::kMaxUrlBytes);
}

std::string ShortenHref(std::string href) {
    if (href.find("baidu.com/link") != std::string::npos) {
        return "https://www.baidu.com/link";
    }
    return ShortenUrl(std::move(href));
}

bool IsBrowserRenderClass(const wchar_t* cls) {
    if (!cls || !cls[0]) return false;
    if (wcsstr(cls, L"Chrome_RenderWidgetHostHWND")) return true;
    if (wcsstr(cls, L"Intermediate D3D Window")) return true;
    return false;
}

bool IsWeakUiClass(const wchar_t* cls) {
    if (!cls || !cls[0]) return true;
    if (wcsstr(cls, L"MMUI")) return true;
    if (wcsstr(cls, L"Chrome_Render")) return true;
    if (wcsstr(cls, L"Render")) return true;
    return false;
}

std::string JsonEscapeProp(const std::string& s) {
    std::string out;
    out.reserve(s.size() + 8);
    for (unsigned char c : s) {
        if (c == '"') out += "\\\"";
        else if (c == '\\') out += "\\\\";
        else if (c < 0x20) out.push_back(' ');
        else out.push_back(static_cast<char>(c));
    }
    return out;
}

}  // namespace

std::uint64_t DeviceRecorder::SessionElapsedMs() const {
    if (sessionStartTick_ == 0) return 0;
    return GetTickCount64() - sessionStartTick_;
}

void DeviceRecorder::EmitTxn(const char* name, bool starter, bool closer,
                             const std::string& propsJson) {
    if (!txnBuilder_) return;
    TransactionBuilder::Step step;
    step.name = name;
    step.t_ms = SessionElapsedMs();
    step.propsJson = propsJson;
    txnBuilder_->OnStep(step, starter, closer);
}

DeviceRecorder::DeviceRecorder(std::wstring outputPath)
    : outputPath_(std::move(outputPath)) {
    buffer_.reserve(kBufferFlushBytes * 2);
}

DeviceRecorder::~DeviceRecorder() {
    Stop();
}

void CALLBACK DeviceRecorder::WinEventProc(
    HWINEVENTHOOK, DWORD event, HWND hwnd,
    LONG idObject, LONG /*idChild*/, DWORD /*eventThread*/, DWORD /*timeMs*/) {
    if (!g_activeRecorder || !g_activeRecorder->IsRunning()) return;
    if (idObject != OBJID_WINDOW && idObject != OBJID_CLIENT) return;
    g_activeRecorder->OnWinEvent(event, hwnd);
}

bool DeviceRecorder::InstallUiHooks() {
    // 只监听前台切换；不再监听 FOCUS（噪音大）
    hookForeground_ = SetWinEventHook(
        EVENT_SYSTEM_FOREGROUND, EVENT_SYSTEM_FOREGROUND,
        nullptr, WinEventProc, 0, 0,
        WINEVENT_OUTOFCONTEXT | WINEVENT_SKIPOWNPROCESS);
    return hookForeground_ != nullptr;
}

void DeviceRecorder::RemoveUiHooks() {
    if (hookForeground_) {
        UnhookWinEvent(hookForeground_);
        hookForeground_ = nullptr;
    }
}

void DeviceRecorder::WriteForegroundIfProcChanged(HWND hwnd) {
    if (!hwnd || !IsWindow(hwnd)) return;

    DWORD pid = 0;
    GetWindowThreadProcessId(hwnd, &pid);
    const std::string proc = WideToUtf8Trunc(ProcessFileName(pid), drb::kMaxProcBytes);
    if (proc.empty() || proc == lastForegroundProc_) return;

    lastForegroundProc_ = proc;
    lastForegroundHwnd_ = hwnd;

    std::vector<char> payload;
    payload.reserve(8 + 4 + 40);
    // 精简：不写窗口标题
    AppendHwndPidProcTitle(payload, hwnd, false);
    WriteRecord(drb::Foreground, payload.data(), payload.size());
    EmitTxn("WindowActivated", false, false,
            std::string("\"proc\":\"") + JsonEscapeProp(proc) + "\"");
}

void DeviceRecorder::WriteClickTarget(std::uint8_t button) {
    HWND hwnd = WindowFromCursorDeep();
    if (messageHwnd_) {
        HWND root = hwnd ? GetAncestor(hwnd, GA_ROOT) : nullptr;
        if (hwnd == messageHwnd_ || root == messageHwnd_) {
            hwnd = nullptr;
        }
    }

    wchar_t classW[256]{};
    if (hwnd) GetClassNameW(hwnd, classW, 256);

    // 浏览器渲染面 / 弱 UI：仍写精简 CLICK（保证有点击就落盘），DOM 细节靠 BROWSER_CLICK
    const bool browserSurface = IsBrowserRenderClass(classW);
    const bool weak = browserSurface || IsWeakUiClass(classW);
    const std::string cls =
        weak ? std::string{} : WideToUtf8Trunc(classW, drb::kMaxClassBytes);

    std::vector<char> payload;
    payload.reserve(1 + 80);
    payload.push_back(static_cast<char>(button));
    AppendHwndPidProcTitle(payload, hwnd, false);  // 不写 title
    AppendLenString(payload, cls);

    WriteRecord(drb::ClickTarget, payload.data(), payload.size());

    DWORD pid = 0;
    if (hwnd) GetWindowThreadProcessId(hwnd, &pid);
    const std::string proc = WideToUtf8Trunc(ProcessFileName(pid), drb::kMaxProcBytes);
    const char* btnName = "L";
    if (button == 2) btnName = "R";
    else if (button == 3) btnName = "M";
    else if (button >= 4) btnName = "X";
    EmitTxn("MouseClick", true, false,
            std::string("\"button\":\"") + btnName + "\",\"proc\":\"" +
                JsonEscapeProp(proc) + "\"");
}

void DeviceRecorder::WriteBrowserClickJson(const std::string& json) {
    if (!running_.load()) return;

    const int button = JsonGetInt(json, "button", 0);
    const std::string url = ShortenUrl(JsonGetString(json, "url"));
    const std::string pageTitle =
        Utf8TruncBytes(JsonGetString(json, "page_title"), drb::kMaxPageTitleBytes);
    const std::string tag = Utf8TruncBytes(JsonGetString(json, "tag"), drb::kMaxTagBytes);
    const std::string id = Utf8TruncBytes(JsonGetString(json, "id"), drb::kMaxDomIdBytes);
    const std::string cls = Utf8TruncBytes(JsonGetString(json, "class"), drb::kMaxDomClassBytes);
    const std::string text = Utf8TruncBytes(JsonGetString(json, "text"), drb::kMaxDomTextBytes);
    const std::string href = ShortenHref(JsonGetString(json, "href"));
    const std::string css;  // 不记 css_path

    std::vector<char> payload;
    payload.reserve(1 + 300);
    payload.push_back(static_cast<char>(static_cast<std::uint8_t>(
        button < 0 ? 0 : (button > 2 ? 2 : button))));
    AppendLenString(payload, url);
    AppendLenString(payload, pageTitle);
    AppendLenString(payload, tag);
    AppendLenString(payload, id);
    AppendLenString(payload, cls);
    AppendLenString(payload, text);
    AppendLenString(payload, href);
    AppendLenString(payload, css);

    WriteRecord(drb::BrowserClick, payload.data(), payload.size());

    std::string props = "\"tag\":\"";
    props += JsonEscapeProp(tag);
    props += "\",\"text\":\"";
    props += JsonEscapeProp(text);
    props += "\",\"url\":\"";
    props += JsonEscapeProp(url);
    props += "\"";
    EmitTxn("DomClick", true, false, props);
}

void DeviceRecorder::WriteBrowserTabJson(const std::string& json) {
    if (!running_.load()) return;

    const std::string actionStr = JsonGetString(json, "action");
    std::uint8_t action = 0;
    if (actionStr == "create") action = 1;
    else if (actionStr == "close") action = 2;
    else if (actionStr == "active") action = 3;
    else return;

    const int tabId = JsonGetInt(json, "tab_id", 0);
    const std::string url = ShortenUrl(JsonGetString(json, "url"));
    const std::string title =
        Utf8TruncBytes(JsonGetString(json, "page_title"), drb::kMaxPageTitleBytes);

    std::vector<char> payload;
    payload.reserve(1 + 4 + 120);
    payload.push_back(static_cast<char>(action));
    const std::uint32_t tid = static_cast<std::uint32_t>(tabId < 0 ? 0 : tabId);
    payload.insert(payload.end(), reinterpret_cast<const char*>(&tid),
                   reinterpret_cast<const char*>(&tid) + sizeof(tid));
    AppendLenString(payload, url);
    AppendLenString(payload, title);

    WriteRecord(drb::BrowserTab, payload.data(), payload.size());

    const char* name = "TabActive";
    bool starter = false;
    if (action == 1) {
        name = "TabCreate";
        starter = true;
    } else if (action == 2) {
        name = "TabClose";
        starter = true;
    }
    std::string props = "\"tab\":";
    props += std::to_string(tid);
    props += ",\"url\":\"";
    props += JsonEscapeProp(url);
    props += "\"";
    EmitTxn(name, starter, false, props);
}

void DeviceRecorder::WriteBrowserEventJson(const std::string& json) {
    const std::string type = JsonGetString(json, "type");
    if (type == "browser_tab") {
        WriteBrowserTabJson(json);
        return;
    }
    if (type == "browser_nav") {
        WriteBrowserNavJson(json);
        return;
    }
    if (type == "browser_session") {
        WriteBrowserSessionJson(json);
        return;
    }
    // browser_click 或旧版无 type 字段
    WriteBrowserClickJson(json);
}

void DeviceRecorder::WriteBrowserNavJson(const std::string& json) {
    if (!running_.load()) return;

    const int tabId = JsonGetInt(json, "tab_id", 0);
    const std::string url = ShortenUrl(JsonGetString(json, "url"));
    const std::string title =
        Utf8TruncBytes(JsonGetString(json, "page_title"), drb::kMaxPageTitleBytes);

    std::vector<char> payload;
    payload.reserve(4 + 120);
    const std::uint32_t tid = static_cast<std::uint32_t>(tabId < 0 ? 0 : tabId);
    payload.insert(payload.end(), reinterpret_cast<const char*>(&tid),
                   reinterpret_cast<const char*>(&tid) + sizeof(tid));
    AppendLenString(payload, url);
    AppendLenString(payload, title);

    WriteRecord(drb::BrowserNav, payload.data(), payload.size());

    std::string props = "\"tab\":";
    props += std::to_string(tid);
    props += ",\"url\":\"";
    props += JsonEscapeProp(url);
    props += "\"";
    EmitTxn("NavCompleted", false, true, props);
}

void DeviceRecorder::WriteSessionRecord(std::uint8_t type, const std::string& snapshotJson) {
    std::string snap = snapshotJson;
    if (snap.size() > drb::kMaxSessionJsonBytes) {
        snap.resize(drb::kMaxSessionJsonBytes);
        while (!snap.empty() && (static_cast<unsigned char>(snap.back()) & 0xC0) == 0x80) {
            snap.pop_back();
        }
    }
    const auto len = static_cast<std::uint16_t>(snap.size());
    std::vector<char> payload;
    payload.reserve(2 + snap.size());
    payload.push_back(static_cast<char>(len & 0xFF));
    payload.push_back(static_cast<char>((len >> 8) & 0xFF));
    payload.insert(payload.end(), snap.begin(), snap.end());
    WriteRecord(type, payload.data(), payload.size());
}

void DeviceRecorder::WriteSessionEndFromCache() {
    if (!browserSessionOpen_) return;

    std::string snap = lastBrowserSnapshotJson_;
    if (snap.empty()) {
        snap = "{\"type\":\"browser_session\",\"phase\":\"end\",\"tab_count\":0,\"tabs\":[]}";
    } else {
        // 缓存可能是 start/update，落盘时统一标为 end
        const auto pos = snap.find("\"phase\":\"");
        if (pos != std::string::npos) {
            const auto val = pos + 9;
            const auto endq = snap.find('"', val);
            if (endq != std::string::npos) {
                snap.replace(val, endq - val, "end");
            }
        }
    }
    WriteSessionRecord(drb::BrowserSessionEnd, snap);
    browserSessionOpen_ = false;
}

void DeviceRecorder::WriteBrowserSessionJson(const std::string& json) {
    if (!running_.load()) return;

    const std::string phase = JsonGetString(json, "phase");
    if (phase.empty()) return;

    if (phase == "update") {
        lastBrowserSnapshotJson_ = json;
        browserProcessSeen_ = true;
        return;
    }

    if (phase == "start") {
        if (browserSessionOpen_) {
            WriteSessionEndFromCache();
        }
        lastBrowserSnapshotJson_ = json;
        WriteSessionRecord(drb::BrowserSessionStart, json);
        browserSessionOpen_ = true;
        browserProcessSeen_ = true;
        return;
    }

    if (phase == "end") {
        lastBrowserSnapshotJson_ = json;
        if (browserSessionOpen_) {
            WriteSessionRecord(drb::BrowserSessionEnd, json);
            browserSessionOpen_ = false;
        }
        return;
    }
}

bool DeviceRecorder::IsBrowserProcessRunning() {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return false;

    PROCESSENTRY32W pe{};
    pe.dwSize = sizeof(pe);
    bool found = false;
    if (Process32FirstW(snap, &pe)) {
        do {
            if (_wcsicmp(pe.szExeFile, L"chrome.exe") == 0 ||
                _wcsicmp(pe.szExeFile, L"msedge.exe") == 0) {
                found = true;
                break;
            }
        } while (Process32NextW(snap, &pe));
    }
    CloseHandle(snap);
    return found;
}

void DeviceRecorder::CheckBrowserProcessExit() {
    const bool runningNow = IsBrowserProcessRunning();
    if (runningNow) {
        browserProcessSeen_ = true;
        return;
    }
    // 曾见过浏览器进程，现在没有 → 写最终状态
    if (browserProcessSeen_ && browserSessionOpen_) {
        WriteSessionEndFromCache();
    }
    browserProcessSeen_ = false;
}

void DeviceRecorder::OnWinEvent(DWORD event, HWND hwnd) {
    if (!running_.load()) return;

    if (event == EVENT_SYSTEM_FOREGROUND) {
        HWND target = ResolveInterestingHwnd(hwnd);
        if (!target) return;
        if (messageHwnd_ && (target == messageHwnd_ || GetWindow(target, GW_OWNER) == messageHwnd_)) {
            return;
        }
        WriteForegroundIfProcChanged(target);
    }
    // FOCUS 已忽略
}

bool DeviceRecorder::Start(HWND hwnd) {
    if (running_.load()) return true;

    out_.open(outputPath_, std::ios::out | std::ios::trunc | std::ios::binary);
    if (!out_) return false;

    drb::Header hdr{};
    std::memcpy(hdr.magic, drb::kMagic, 4);
    hdr.version = drb::kVersion;
    hdr.reserved = 0;
    out_.write(reinterpret_cast<const char*>(&hdr), sizeof(hdr));
    if (!out_) {
        out_.close();
        return false;
    }
    out_.flush();  // 立刻落盘，避免采集中查看显示 0 字节
    if (out_.rdbuf()) out_.rdbuf()->pubsync();

    // 注册键盘 + 鼠标
    RAWINPUTDEVICE rid[2]{};
    rid[0].usUsagePage = 0x01;
    rid[0].usUsage = 0x06;  // keyboard
    rid[0].dwFlags = RIDEV_INPUTSINK;
    rid[0].hwndTarget = hwnd;
    rid[1].usUsagePage = 0x01;
    rid[1].usUsage = 0x02;  // mouse
    rid[1].dwFlags = RIDEV_INPUTSINK;
    rid[1].hwndTarget = hwnd;

    if (!RegisterRawInputDevices(rid, 2, sizeof(RAWINPUTDEVICE))) {
        out_.close();
        return false;
    }

    messageHwnd_ = hwnd;
    sessionStartTick_ = GetTickCount64();
    lastEventTick_ = sessionStartTick_;
    eventCount_.store(0);
    lastKeyVkey_ = 0;
    lastKeyDown_ = false;
    lastForegroundHwnd_ = nullptr;
    lastForegroundProc_.clear();
    browserSessionOpen_ = false;
    browserProcessSeen_ = false;
    lastBrowserSnapshotJson_.clear();

    {
        std::wstring txnPath = outputPath_;
        const size_t dot = txnPath.find_last_of(L'.');
        if (dot != std::wstring::npos) txnPath = txnPath.substr(0, dot);
        txnPath += L".txn.jsonl";
        txnBuilder_ = std::make_unique<TransactionBuilder>(std::move(txnPath));
        txnBuilder_->Start();
    }

    g_activeRecorder = this;
    running_.store(true);

    bridge_ = std::make_unique<BrowserBridge>();
    if (!bridge_->Start(static_cast<std::uint16_t>(drb::kBrowserBridgePort))) {
        bridge_.reset();
    }

    InstallUiHooks();

    HWND fg = GetForegroundWindow();
    if (fg) WriteForegroundIfProcChanged(fg);

    return true;
}

void DeviceRecorder::Stop() {
    if (!running_.exchange(false)) {
        if (out_.is_open()) out_.close();
        return;
    }

    RemoveUiHooks();
    if (bridge_) {
        bridge_->Stop();
        bridge_.reset();
    }

    // 退出采集前补写浏览器最终状态
    WriteSessionEndFromCache();

    if (txnBuilder_) {
        txnBuilder_->Stop();
        txnBuilder_.reset();
    }

    if (g_activeRecorder == this) g_activeRecorder = nullptr;

    WriteRecord(drb::End, nullptr, 0);

    {
        std::lock_guard<std::mutex> lock(mutex_);
        if (!buffer_.empty() && out_.is_open()) {
            out_.write(buffer_.data(), static_cast<std::streamsize>(buffer_.size()));
            buffer_.clear();
        }
        if (out_.is_open()) {
            out_.flush();
            out_.close();
        }
    }

    RAWINPUTDEVICE rid[2]{};
    rid[0].usUsagePage = 0x01;
    rid[0].usUsage = 0x06;
    rid[0].dwFlags = RIDEV_REMOVE;
    rid[0].hwndTarget = nullptr;
    rid[1].usUsagePage = 0x01;
    rid[1].usUsage = 0x02;
    rid[1].dwFlags = RIDEV_REMOVE;
    rid[1].hwndTarget = nullptr;
    RegisterRawInputDevices(rid, 2, sizeof(RAWINPUTDEVICE));
    messageHwnd_ = nullptr;
}

void DeviceRecorder::WriteBytes(const void* data, size_t size) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!out_.is_open() || size == 0) return;

    const char* p = static_cast<const char*>(data);
    buffer_.insert(buffer_.end(), p, p + size);
    if (buffer_.empty()) return;

    out_.write(buffer_.data(), static_cast<std::streamsize>(buffer_.size()));
    buffer_.clear();
    out_.flush();
    if (out_.rdbuf()) {
        out_.rdbuf()->pubsync();
    }
}

std::uint16_t DeviceRecorder::NextDtMs() {
    const ULONGLONG now = GetTickCount64();
    ULONGLONG dt = now - lastEventTick_;
    lastEventTick_ = now;
    if (dt > 65535) dt = 65535;
    return static_cast<std::uint16_t>(dt);
}

void DeviceRecorder::WriteRecord(std::uint8_t type, const void* payload, size_t payloadSize) {
    drb::RecHead head{};
    head.type = type;
    head.dt_ms = NextDtMs();
    WriteBytes(&head, sizeof(head));
    if (payload && payloadSize > 0) {
        WriteBytes(payload, payloadSize);
    }
    eventCount_.fetch_add(1);
}

void DeviceRecorder::OnKeyboard(const RAWINPUT& ri) {
    const RAWKEYBOARD& kb = ri.data.keyboard;
    if (kb.VKey == 0xFF) return;

    const bool down = !(kb.Flags & RI_KEY_BREAK);
    // 忽略按住时的自动重复 down
    if (down && lastKeyDown_ && lastKeyVkey_ == kb.VKey) return;
    lastKeyVkey_ = kb.VKey;
    lastKeyDown_ = down;

#pragma pack(push, 1)
    struct Payload {
        std::uint8_t down;
        std::uint16_t vkey;
    } p{static_cast<std::uint8_t>(down ? 1 : 0), kb.VKey};
#pragma pack(pop)
    WriteRecord(drb::Key, &p, sizeof(p));
    if (down) {
        EmitTxn("KeyDown", true, false,
                std::string("\"vkey\":") + std::to_string(kb.VKey));
    } else {
        EmitTxn("KeyUp", false, false,
                std::string("\"vkey\":") + std::to_string(kb.VKey));
    }
}

void DeviceRecorder::OnMouse(const RAWINPUT& ri) {
    const RAWMOUSE& m = ri.data.mouse;
    if (m.usButtonFlags == 0) return;

    // 只记按下目标；不记抬起、滚轮
    if (m.usButtonFlags & RI_MOUSE_LEFT_BUTTON_DOWN) WriteClickTarget(1);
    if (m.usButtonFlags & RI_MOUSE_RIGHT_BUTTON_DOWN) WriteClickTarget(2);
    if (m.usButtonFlags & RI_MOUSE_MIDDLE_BUTTON_DOWN) WriteClickTarget(3);
    if (m.usButtonFlags & RI_MOUSE_BUTTON_4_DOWN) WriteClickTarget(4);
    if (m.usButtonFlags & RI_MOUSE_BUTTON_5_DOWN) WriteClickTarget(5);
}

void DeviceRecorder::Poll() {
    if (!running_.load()) return;
    CheckBrowserProcessExit();
    if (txnBuilder_) {
        txnBuilder_->Poll(SessionElapsedMs());
    }
}

void DeviceRecorder::HandleRawInput(HRAWINPUT hRawInput) {
    if (!running_.load()) return;

    UINT size = 0;
    GetRawInputData(hRawInput, RID_INPUT, nullptr, &size, sizeof(RAWINPUTHEADER));
    if (size == 0) return;

    std::vector<BYTE> buf(size);
    if (GetRawInputData(hRawInput, RID_INPUT, buf.data(), &size, sizeof(RAWINPUTHEADER)) != size) {
        return;
    }

    const RAWINPUT* ri = reinterpret_cast<const RAWINPUT*>(buf.data());
    switch (ri->header.dwType) {
        case RIM_TYPEKEYBOARD:
            OnKeyboard(*ri);
            break;
        case RIM_TYPEMOUSE:
            OnMouse(*ri);
            break;
        default:
            break;
    }
}
