#include "BrowserBridge.h"
#include "DeviceRecorder.h"
#include "EventFormat.h"

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <winsock2.h>
#include <ws2tcpip.h>

#include <cstring>
#include <string>
#include <vector>

namespace {

std::string Utf8Trunc(std::string s, size_t maxBytes) {
    if (s.size() <= maxBytes) return s;
    size_t cut = maxBytes;
    while (cut > 0 && (static_cast<unsigned char>(s[cut]) & 0xC0) == 0x80) --cut;
    s.resize(cut);
    return s;
}

// 极简 JSON 字符串提取："key":"value"（不处理复杂转义以外的 \" \\）
std::string JsonGetString(const std::string& json, const char* key) {
    const std::string pat = std::string("\"") + key + "\"";
    size_t pos = json.find(pat);
    if (pos == std::string::npos) return {};
    pos = json.find(':', pos + pat.size());
    if (pos == std::string::npos) return {};
    ++pos;
    while (pos < json.size() && (json[pos] == ' ' || json[pos] == '\t')) ++pos;
    if (pos >= json.size() || json[pos] != '"') return {};
    ++pos;
    std::string out;
    while (pos < json.size()) {
        const char c = json[pos++];
        if (c == '\\' && pos < json.size()) {
            const char n = json[pos++];
            if (n == '"' || n == '\\' || n == '/') out.push_back(n);
            else if (n == 'n') out.push_back('\n');
            else if (n == 't') out.push_back('\t');
            else out.push_back(n);
            continue;
        }
        if (c == '"') break;
        out.push_back(c);
    }
    return out;
}

int JsonGetInt(const std::string& json, const char* key, int defVal) {
    const std::string pat = std::string("\"") + key + "\"";
    size_t pos = json.find(pat);
    if (pos == std::string::npos) return defVal;
    pos = json.find(':', pos + pat.size());
    if (pos == std::string::npos) return defVal;
    ++pos;
    while (pos < json.size() && (json[pos] == ' ' || json[pos] == '\t')) ++pos;
    try {
        return std::stoi(json.substr(pos));
    } catch (...) {
        return defVal;
    }
}

void AppendLenString(std::vector<char>& out, const std::string& s) {
    out.push_back(static_cast<char>(static_cast<std::uint8_t>(s.size())));
    out.insert(out.end(), s.begin(), s.end());
}

void SendAll(SOCKET s, const char* data, int len) {
    int sent = 0;
    while (sent < len) {
        const int n = send(s, data + sent, len - sent, 0);
        if (n <= 0) return;
        sent += n;
    }
}

void SendHttp(SOCKET s, int code, const char* status, const char* body) {
    char header[256];
    const int bodyLen = body ? static_cast<int>(std::strlen(body)) : 0;
    const int n = std::snprintf(
        header, sizeof(header),
        "HTTP/1.1 %d %s\r\n"
        "Content-Type: application/json; charset=utf-8\r\n"
        "Content-Length: %d\r\n"
        "Access-Control-Allow-Origin: *\r\n"
        "Access-Control-Allow-Methods: POST, OPTIONS\r\n"
        "Access-Control-Allow-Headers: Content-Type\r\n"
        "Connection: close\r\n"
        "\r\n",
        code, status, bodyLen);
    if (n > 0) SendAll(s, header, n);
    if (bodyLen > 0) SendAll(s, body, bodyLen);
}

}  // namespace

BrowserBridge::~BrowserBridge() {
    Stop();
}

bool BrowserBridge::Start(std::uint16_t port) {
    if (running_.load()) return true;

    WSADATA wsa{};
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) return false;

    SOCKET listenSock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (listenSock == INVALID_SOCKET) {
        WSACleanup();
        return false;
    }

    BOOL yes = TRUE;
    setsockopt(listenSock, SOL_SOCKET, SO_REUSEADDR, reinterpret_cast<const char*>(&yes), sizeof(yes));

    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    inet_pton(AF_INET, "127.0.0.1", &addr.sin_addr);

    if (bind(listenSock, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) != 0 ||
        listen(listenSock, 8) != 0) {
        closesocket(listenSock);
        WSACleanup();
        return false;
    }

    // 非阻塞 accept + 短超时，便于 Stop
    DWORD timeout = 500;
    setsockopt(listenSock, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char*>(&timeout), sizeof(timeout));

    listenSock_ = static_cast<uintptr_t>(listenSock);
    port_ = port;
    running_.store(true);
    thread_ = std::thread([this] { ThreadMain(); });
    return true;
}

void BrowserBridge::Stop() {
    if (!running_.exchange(false)) return;

    if (listenSock_) {
        closesocket(static_cast<SOCKET>(listenSock_));
        listenSock_ = 0;
    }
    if (thread_.joinable()) thread_.join();
    WSACleanup();
}

void BrowserBridge::ThreadMain() {
    while (running_.load()) {
        SOCKET listenSock = static_cast<SOCKET>(listenSock_);
        if (listenSock == 0 || listenSock == INVALID_SOCKET) break;

        sockaddr_in clientAddr{};
        int addrLen = sizeof(clientAddr);
        SOCKET client = accept(listenSock, reinterpret_cast<sockaddr*>(&clientAddr), &addrLen);
        if (client == INVALID_SOCKET) {
            const int err = WSAGetLastError();
            if (!running_.load()) break;
            if (err == WSAETIMEDOUT || err == WSAEWOULDBLOCK) continue;
            // listen 被关闭
            if (err == WSAEINTR || err == WSAENOTSOCK || err == WSAEINVAL) break;
            continue;
        }
        HandleClient(static_cast<uintptr_t>(client));
        closesocket(client);
    }
}

void BrowserBridge::HandleClient(uintptr_t clientSock) {
    SOCKET s = static_cast<SOCKET>(clientSock);
    std::string req;
    char buf[2048];
    for (;;) {
        const int n = recv(s, buf, sizeof(buf), 0);
        if (n <= 0) break;
        req.append(buf, buf + n);
        if (req.find("\r\n\r\n") != std::string::npos) break;
        if (req.size() > 1024 * 64) break;
    }

    if (req.empty()) return;

    // OPTIONS 预检
    if (req.rfind("OPTIONS ", 0) == 0) {
        SendHttp(s, 204, "No Content", nullptr);
        return;
    }

    if (req.find("POST /click") == std::string::npos &&
        req.find("POST /event") == std::string::npos) {
        SendHttp(s, 404, "Not Found", "{\"ok\":0,\"err\":\"not_found\"}");
        return;
    }

    const size_t headerEnd = req.find("\r\n\r\n");
    if (headerEnd == std::string::npos) {
        SendHttp(s, 400, "Bad Request", "{\"ok\":0}");
        return;
    }

    int contentLength = 0;
    {
        const size_t clPos = req.find("Content-Length:");
        if (clPos != std::string::npos && clPos < headerEnd) {
            contentLength = std::atoi(req.c_str() + clPos + 15);
        }
    }

    std::string body = req.substr(headerEnd + 4);
    while (static_cast<int>(body.size()) < contentLength) {
        const int n = recv(s, buf, sizeof(buf), 0);
        if (n <= 0) break;
        body.append(buf, buf + n);
    }
    if (contentLength > 0 && static_cast<int>(body.size()) > contentLength) {
        body.resize(static_cast<size_t>(contentLength));
    }

    if (g_activeRecorder && g_activeRecorder->IsRunning()) {
        g_activeRecorder->WriteBrowserEventJson(body);
        SendHttp(s, 200, "OK", "{\"ok\":1}");
    } else {
        SendHttp(s, 503, "Unavailable", "{\"ok\":0,\"err\":\"recorder_stopped\"}");
    }
}
