#pragma once

#include <cstdint>

// DevRecoder 紧凑二进制事件格式 (.drb)
// 小端序。每条记录: type(u8) + dt_ms(u16) + payload
// dt_ms = 距上一条事件的毫秒数，上限 65535

namespace drb {

constexpr char kMagic[4] = {'D', 'R', 'B', '1'};
constexpr std::uint16_t kVersion = 1;

enum Type : std::uint8_t {
    Key = 0x01,
    Btn = 0x02,
    Wheel = 0x03,
    Move = 0x04,
    MouseStop = 0x05,
    XInput = 0x06,
    XConn = 0x07,

    Focus = 0x10,
    Foreground = 0x11,
    ClickTarget = 0x12,

    // 浏览器扩展点击（本机 HTTP 推送）
    // payload: button(u8) 0左 1中 2右
    //   + url_len(u8)+url
    //   + page_title_len(u8)+page_title
    //   + tag_len(u8)+tag
    //   + id_len(u8)+id
    //   + class_len(u8)+class
    //   + text_len(u8)+text
    //   + href_len(u8)+href
    //   + css_len(u8)+css_path
    BrowserClick = 0x13,

    // 浏览器标签事件（扩展 tabs API）
    // payload: action(u8) 1=create 2=close 3=active
    //        + tab_id(u32)
    //        + url_len(u8)+url
    //        + title_len(u8)+title
    BrowserTab = 0x14,

    // 浏览器主导航完成（webNavigation.onCompleted）
    // payload: tab_id(u32) + url_len(u8)+url + title_len(u8)+title
    BrowserNav = 0x15,

    // 浏览器会话书档（初始/最终状态快照）
    // payload: json_len(u16 LE) + utf8_json
    BrowserSessionStart = 0x16,
    BrowserSessionEnd = 0x17,

    End = 0xFF,
};

constexpr std::uint8_t kMaxProcBytes = 32;
constexpr std::uint8_t kMaxTitleBytes = 64;
constexpr std::uint8_t kMaxClassBytes = 48;

constexpr std::uint8_t kMaxUrlBytes = 96;
constexpr std::uint8_t kMaxPageTitleBytes = 48;
constexpr std::uint8_t kMaxTagBytes = 24;
constexpr std::uint8_t kMaxDomIdBytes = 48;
constexpr std::uint8_t kMaxDomClassBytes = 48;
constexpr std::uint8_t kMaxDomTextBytes = 64;
constexpr std::uint8_t kMaxHrefBytes = 96;
constexpr std::uint8_t kMaxCssPathBytes = 0;  // 不再记录 css_path
constexpr std::uint16_t kMaxSessionJsonBytes = 4096;

// 浏览器桥默认端口
constexpr unsigned kBrowserBridgePort = 17890;

#pragma pack(push, 1)
struct Header {
    char magic[4];
    std::uint16_t version;
    std::uint16_t reserved;
};

struct RecHead {
    std::uint8_t type;
    std::uint16_t dt_ms;
};
#pragma pack(pop)

}  // namespace drb
