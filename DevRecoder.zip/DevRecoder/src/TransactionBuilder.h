#pragma once

#include <cstdint>
#include <fstream>
#include <mutex>
#include <string>
#include <vector>

// Layer2：把相关触发事件聚成 Transaction #N，写入 .txn.jsonl
class TransactionBuilder {
public:
    struct Step {
        std::string name;
        std::uint64_t t_ms = 0;
        std::string propsJson;  // 已是 {"k":"v",...} 片段，不含外层花括号；可空
    };

    explicit TransactionBuilder(std::wstring jsonlPath);
    ~TransactionBuilder();

    TransactionBuilder(const TransactionBuilder&) = delete;
    TransactionBuilder& operator=(const TransactionBuilder&) = delete;

    void Start();
    void Stop();  // 强制关闭未完成事务并刷盘

    // t_ms：相对采集会话起点的毫秒
    void OnStep(const Step& step, bool isStarter, bool isCloser);
    void Poll(std::uint64_t nowMs);

    std::uint64_t TransactionCount() const { return nextId_ > 1 ? nextId_ - 1 : 0; }

private:
    void CloseOpen(std::uint64_t endMs);
    void FlushLine(const std::string& line);
    static std::string Escape(const std::string& s);

    static constexpr std::uint64_t kIdleMs = 800;
    static constexpr std::uint64_t kMaxMs = 5000;

    std::wstring path_;
    std::ofstream out_;
    std::mutex mutex_;

    std::uint64_t nextId_{1};
    bool open_{false};
    std::uint64_t id_{0};
    std::uint64_t tStart_{0};
    std::uint64_t tLast_{0};
    std::vector<Step> steps_;
};
