#pragma once

#include <atomic>
#include <cstdint>
#include <string>
#include <thread>

// 本机 HTTP 桥：接收 Chrome 扩展 POST /click JSON
class BrowserBridge {
public:
    BrowserBridge() = default;
    ~BrowserBridge();

    BrowserBridge(const BrowserBridge&) = delete;
    BrowserBridge& operator=(const BrowserBridge&) = delete;

    bool Start(std::uint16_t port = 17890);
    void Stop();
    bool IsRunning() const { return running_.load(); }
    std::uint16_t Port() const { return port_; }

private:
    void ThreadMain();
    void HandleClient(uintptr_t clientSock);

    std::atomic<bool> running_{false};
    std::uint16_t port_{17890};
    uintptr_t listenSock_{0};  // SOCKET
    std::thread thread_;
};
