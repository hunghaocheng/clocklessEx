#pragma once

#include "EventFormat.h"
#include "BrowserBridge.h"
#include "TransactionBuilder.h"

#include <windows.h>
#include <string>
#include <fstream>
#include <mutex>
#include <atomic>
#include <vector>
#include <cstdint>
#include <memory>

// 采集外设触发 + 窗口/焦点变化 + 点击目标 + 浏览器扩展点击
class DeviceRecorder {
public:
    explicit DeviceRecorder(std::wstring outputPath);
    ~DeviceRecorder();

    DeviceRecorder(const DeviceRecorder&) = delete;
    DeviceRecorder& operator=(const DeviceRecorder&) = delete;

    bool Start(HWND hwnd);
    void Stop();
    void HandleRawInput(HRAWINPUT hRawInput);
    void Poll();
    void OnWinEvent(DWORD event, HWND hwnd);

    // 供 BrowserBridge 调用：写入浏览器事件 JSON（click / tab / nav / session）
    void WriteBrowserEventJson(const std::string& json);

    bool IsRunning() const { return running_.load(); }
    const std::wstring& OutputPath() const { return outputPath_; }
    std::uint64_t EventCount() const { return eventCount_.load(); }
    std::uint16_t BrowserPort() const { return bridge_ ? bridge_->Port() : 0; }

private:
    void WriteBytes(const void* data, size_t size);
    void WriteRecord(std::uint8_t type, const void* payload, size_t payloadSize);

    void OnKeyboard(const RAWINPUT& ri);
    void OnMouse(const RAWINPUT& ri);

    bool InstallUiHooks();
    void RemoveUiHooks();
    void WriteForegroundIfProcChanged(HWND hwnd);
    void WriteClickTarget(std::uint8_t button);
    void WriteBrowserClickJson(const std::string& json);
    void WriteBrowserTabJson(const std::string& json);
    void WriteBrowserNavJson(const std::string& json);
    void WriteBrowserSessionJson(const std::string& json);
    void WriteSessionRecord(std::uint8_t type, const std::string& snapshotJson);
    void WriteSessionEndFromCache();
    void CheckBrowserProcessExit();
    static bool IsBrowserProcessRunning();

    std::uint64_t SessionElapsedMs() const;
    void EmitTxn(const char* name, bool starter, bool closer, const std::string& propsJson);

    std::uint16_t NextDtMs();

    static void CALLBACK WinEventProc(
        HWINEVENTHOOK hook, DWORD event, HWND hwnd,
        LONG idObject, LONG idChild, DWORD eventThread, DWORD timeMs);

    static constexpr size_t kBufferFlushBytes = 4096;

    std::wstring outputPath_;
    std::ofstream out_;
    std::mutex mutex_;
    std::vector<char> buffer_;
    std::atomic<bool> running_{false};
    std::atomic<std::uint64_t> eventCount_{0};
    HWND messageHwnd_{nullptr};

    ULONGLONG sessionStartTick_{0};
    ULONGLONG lastEventTick_{0};

    USHORT lastKeyVkey_{0};
    bool lastKeyDown_{false};

    HWINEVENTHOOK hookForeground_{nullptr};
    HWND lastForegroundHwnd_{nullptr};
    std::string lastForegroundProc_;

    std::unique_ptr<BrowserBridge> bridge_;
    std::unique_ptr<TransactionBuilder> txnBuilder_;

    // 浏览器会话书档
    bool browserSessionOpen_{false};
    bool browserProcessSeen_{false};
    std::string lastBrowserSnapshotJson_;
};

extern DeviceRecorder* g_activeRecorder;
