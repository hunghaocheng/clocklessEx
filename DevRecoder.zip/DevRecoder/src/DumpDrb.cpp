#include "EventFormat.h"

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>

#include <cstdio>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

namespace {

bool ReadExact(std::ifstream& in, void* dst, size_t n) {
    in.read(static_cast<char*>(dst), static_cast<std::streamsize>(n));
    return static_cast<size_t>(in.gcount()) == n;
}

const char* BtnName(std::uint8_t b) {
    switch (b) {
        case 1: return "L";
        case 2: return "R";
        case 3: return "M";
        case 4: return "X1";
        case 5: return "X2";
        default: return "?";
    }
}

bool ReadUiPayload(std::ifstream& in, std::uint64_t* hwnd, std::uint32_t* pid,
                   std::string* proc, std::string* title) {
    if (!ReadExact(in, hwnd, 8) || !ReadExact(in, pid, 4)) return false;
    std::uint8_t procLen = 0, titleLen = 0;
    if (!ReadExact(in, &procLen, 1)) return false;
    proc->assign(procLen, '\0');
    if (procLen && !ReadExact(in, proc->data(), procLen)) return false;
    if (!ReadExact(in, &titleLen, 1)) return false;
    title->assign(titleLen, '\0');
    if (titleLen && !ReadExact(in, title->data(), titleLen)) return false;
    return true;
}

bool ReadLenString(std::ifstream& in, std::string* s) {
    std::uint8_t n = 0;
    if (!ReadExact(in, &n, 1)) return false;
    s->assign(n, '\0');
    if (n && !ReadExact(in, s->data(), n)) return false;
    return true;
}

std::wstring ReplaceExt(const std::wstring& path, const wchar_t* newExt) {
    const size_t slash = path.find_last_of(L"\\/");
    const size_t dot = path.find_last_of(L'.');
    if (dot != std::wstring::npos && (slash == std::wstring::npos || dot > slash)) {
        return path.substr(0, dot) + newExt;
    }
    return path + newExt;
}

std::wstring ExeDir() {
    wchar_t path[MAX_PATH]{};
    GetModuleFileNameW(nullptr, path, MAX_PATH);
    std::wstring p(path);
    const size_t pos = p.find_last_of(L"\\/");
    if (pos == std::wstring::npos) return L".";
    return p.substr(0, pos);
}

void CollectDrbFiles(const std::wstring& dir, std::vector<std::wstring>* out) {
    const std::wstring pattern = dir + L"\\*.drb";
    WIN32_FIND_DATAW fd{};
    HANDLE h = FindFirstFileW(pattern.c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return;
    do {
        if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) continue;
        out->push_back(dir + L"\\" + fd.cFileName);
    } while (FindNextFileW(h, &fd));
    FindClose(h);
}

bool ConvertOne(const std::wstring& inPath, const std::wstring& outPath, std::wstring* err) {
    std::ifstream in(inPath, std::ios::binary);
    if (!in) {
        *err = L"无法打开: " + inPath;
        return false;
    }

    drb::Header hdr{};
    if (!ReadExact(in, &hdr, sizeof(hdr)) ||
        std::memcmp(hdr.magic, drb::kMagic, 4) != 0) {
        *err = L"非法 .drb: " + inPath;
        return false;
    }

    FILE* fp = nullptr;
    if (_wfopen_s(&fp, outPath.c_str(), L"wb") != 0 || !fp) {
        *err = L"无法创建: " + outPath;
        return false;
    }

    static const unsigned char kBom[] = {0xEF, 0xBB, 0xBF};
    std::fwrite(kBom, 1, 3, fp);
    std::fprintf(fp, "# DRB version=%u\n", hdr.version);

    auto emitEnd = [&] { std::fputc('\n', fp); };

    std::uint64_t t = 0;
    bool ok = true;
    for (;;) {
        drb::RecHead head{};
        if (!ReadExact(in, &head, sizeof(head))) break;
        t += head.dt_ms;

        switch (head.type) {
            case drb::Key: {
                std::uint8_t down = 0;
                std::uint16_t vkey = 0;
                if (!ReadExact(in, &down, 1) || !ReadExact(in, &vkey, 2)) {
                    ok = false;
                    break;
                }
                std::fprintf(fp, "%llu KEY %s vkey=0x%02X",
                             static_cast<unsigned long long>(t),
                             down ? "down" : "up", vkey);
                emitEnd();
                break;
            }
            case drb::Btn: {
                std::uint8_t button = 0, down = 0;
                if (!ReadExact(in, &button, 1) || !ReadExact(in, &down, 1)) {
                    ok = false;
                    break;
                }
                std::fprintf(fp, "%llu BTN %s %s",
                             static_cast<unsigned long long>(t),
                             BtnName(button), down ? "down" : "up");
                emitEnd();
                break;
            }
            case drb::Wheel: {
                std::uint8_t axis = 0;
                std::int16_t delta = 0;
                if (!ReadExact(in, &axis, 1) || !ReadExact(in, &delta, 2)) {
                    ok = false;
                    break;
                }
                std::fprintf(fp, "%llu WHEEL %s delta=%d",
                             static_cast<unsigned long long>(t),
                             axis ? "H" : "V", delta);
                emitEnd();
                break;
            }
            case drb::Move: {
                std::int16_t dx = 0, dy = 0;
                if (!ReadExact(in, &dx, 2) || !ReadExact(in, &dy, 2)) {
                    ok = false;
                    break;
                }
                std::fprintf(fp, "%llu MOVE dx=%d dy=%d",
                             static_cast<unsigned long long>(t), dx, dy);
                emitEnd();
                break;
            }
            case drb::MouseStop:
                std::fprintf(fp, "%llu STOP", static_cast<unsigned long long>(t));
                emitEnd();
                break;
            case drb::XInput: {
                std::uint8_t index = 0, lt = 0, rt = 0;
                std::uint16_t buttons = 0;
                std::int16_t lx = 0, ly = 0, rx = 0, ry = 0;
                if (!ReadExact(in, &index, 1) || !ReadExact(in, &buttons, 2) ||
                    !ReadExact(in, &lt, 1) || !ReadExact(in, &rt, 1) ||
                    !ReadExact(in, &lx, 2) || !ReadExact(in, &ly, 2) ||
                    !ReadExact(in, &rx, 2) || !ReadExact(in, &ry, 2)) {
                    ok = false;
                    break;
                }
                std::fprintf(fp,
                             "%llu XINPUT i=%u btn=0x%04X LT=%u RT=%u LX=%d LY=%d RX=%d RY=%d",
                             static_cast<unsigned long long>(t), index, buttons,
                             lt, rt, lx, ly, rx, ry);
                emitEnd();
                break;
            }
            case drb::XConn: {
                std::uint8_t index = 0, connected = 0;
                if (!ReadExact(in, &index, 1) || !ReadExact(in, &connected, 1)) {
                    ok = false;
                    break;
                }
                std::fprintf(fp, "%llu XCONN i=%u %s",
                             static_cast<unsigned long long>(t), index,
                             connected ? "on" : "off");
                emitEnd();
                break;
            }
            case drb::Focus:
            case drb::Foreground: {
                std::uint64_t hwnd = 0;
                std::uint32_t pid = 0;
                std::string proc, title;
                if (!ReadUiPayload(in, &hwnd, &pid, &proc, &title)) {
                    ok = false;
                    break;
                }
                std::fprintf(fp, "%llu %s hwnd=0x%llX pid=%u proc=%s title=%s",
                             static_cast<unsigned long long>(t),
                             head.type == drb::Focus ? "FOCUS" : "FOREGROUND",
                             static_cast<unsigned long long>(hwnd), pid,
                             proc.c_str(), title.c_str());
                emitEnd();
                break;
            }
            case drb::ClickTarget: {
                std::uint8_t button = 0;
                if (!ReadExact(in, &button, 1)) {
                    ok = false;
                    break;
                }
                std::uint64_t hwnd = 0;
                std::uint32_t pid = 0;
                std::string proc, title, cls;
                if (!ReadUiPayload(in, &hwnd, &pid, &proc, &title) || !ReadLenString(in, &cls)) {
                    ok = false;
                    break;
                }
                std::fprintf(fp, "%llu CLICK %s hwnd=0x%llX pid=%u proc=%s title=%s class=%s",
                             static_cast<unsigned long long>(t),
                             BtnName(button),
                             static_cast<unsigned long long>(hwnd), pid,
                             proc.c_str(), title.c_str(), cls.c_str());
                emitEnd();
                break;
            }
            case drb::BrowserClick: {
                std::uint8_t button = 0;
                if (!ReadExact(in, &button, 1)) {
                    ok = false;
                    break;
                }
                std::string url, pageTitle, tag, id, cls, text, href, css;
                if (!ReadLenString(in, &url) || !ReadLenString(in, &pageTitle) ||
                    !ReadLenString(in, &tag) || !ReadLenString(in, &id) ||
                    !ReadLenString(in, &cls) || !ReadLenString(in, &text) ||
                    !ReadLenString(in, &href) || !ReadLenString(in, &css)) {
                    ok = false;
                    break;
                }
                const char* btn = (button == 1) ? "M" : (button == 2) ? "R" : "L";
                std::fprintf(fp,
                             "%llu BROWSER_CLICK %s url=%s page=%s tag=%s id=%s class=%s text=%s href=%s css=%s",
                             static_cast<unsigned long long>(t), btn,
                             url.c_str(), pageTitle.c_str(), tag.c_str(), id.c_str(),
                             cls.c_str(), text.c_str(), href.c_str(), css.c_str());
                emitEnd();
                break;
            }
            case drb::BrowserTab: {
                std::uint8_t action = 0;
                std::uint32_t tabId = 0;
                if (!ReadExact(in, &action, 1) || !ReadExact(in, &tabId, 4)) {
                    ok = false;
                    break;
                }
                std::string url, title;
                if (!ReadLenString(in, &url) || !ReadLenString(in, &title)) {
                    ok = false;
                    break;
                }
                const char* act =
                    (action == 1) ? "CREATE" : (action == 2) ? "CLOSE" : (action == 3) ? "ACTIVE" : "?";
                std::fprintf(fp, "%llu BROWSER_TAB %s tab=%u url=%s title=%s",
                             static_cast<unsigned long long>(t), act, tabId,
                             url.c_str(), title.c_str());
                emitEnd();
                break;
            }
            case drb::BrowserNav: {
                std::uint32_t tabId = 0;
                if (!ReadExact(in, &tabId, 4)) {
                    ok = false;
                    break;
                }
                std::string url, title;
                if (!ReadLenString(in, &url) || !ReadLenString(in, &title)) {
                    ok = false;
                    break;
                }
                std::fprintf(fp, "%llu BROWSER_NAV tab=%u url=%s title=%s",
                             static_cast<unsigned long long>(t), tabId,
                             url.c_str(), title.c_str());
                emitEnd();
                break;
            }
            case drb::BrowserSessionStart:
            case drb::BrowserSessionEnd: {
                std::uint16_t jsonLen = 0;
                if (!ReadExact(in, &jsonLen, 2)) {
                    ok = false;
                    break;
                }
                std::string json(jsonLen, '\0');
                if (jsonLen && !ReadExact(in, json.data(), jsonLen)) {
                    ok = false;
                    break;
                }
                std::fprintf(fp, "%llu %s %s",
                             static_cast<unsigned long long>(t),
                             head.type == drb::BrowserSessionStart ? "BROWSER_SESSION_START"
                                                                   : "BROWSER_SESSION_END",
                             json.c_str());
                emitEnd();
                break;
            }
            case drb::End:
                std::fprintf(fp, "%llu END", static_cast<unsigned long long>(t));
                emitEnd();
                std::fclose(fp);
                return true;
            default:
                std::fprintf(fp, "%llu UNKNOWN type=0x%02X",
                             static_cast<unsigned long long>(t), head.type);
                emitEnd();
                ok = false;
                break;
        }
        if (!ok) break;
    }

    std::fclose(fp);
    if (!ok) {
        *err = L"解析失败: " + inPath;
        return false;
    }
    return true;
}

int ConvertBatchInExeFolder() {
    const std::wstring dir = ExeDir();
    std::vector<std::wstring> files;
    CollectDrbFiles(dir, &files);
    CollectDrbFiles(dir + L"\\data", &files);

    if (files.empty()) {
        MessageBoxW(nullptr,
                    L"未在程序同级目录及 data 子目录中找到 .drb 文件。\n\n"
                    L"请把 DumpDrb.exe 放在含有 .drb 的目录旁，或放入 build 目录后双击。",
                    L"DumpDrb", MB_ICONINFORMATION);
        return 1;
    }

    int okCount = 0;
    int failCount = 0;
    std::wstring detail;
    for (const auto& inPath : files) {
        const std::wstring outPath = ReplaceExt(inPath, L".txt");
        std::wstring err;
        if (ConvertOne(inPath, outPath, &err)) {
            ++okCount;
            detail += L"✓ " + outPath + L"\n";
        } else {
            ++failCount;
            detail += L"✗ " + err + L"\n";
        }
    }

    // 成功时不弹框（双击转换后直接看 .txt）；仅失败时提示
    if (failCount > 0) {
        wchar_t summary[256]{};
        swprintf_s(summary, L"完成：成功 %d 个，失败 %d 个\n\n", okCount, failCount);
        std::wstring msg = summary + detail;
        if (msg.size() > 1500) {
            msg = msg.substr(0, 1500) + L"\n...";
        }
        MessageBoxW(nullptr, msg.c_str(), L"DumpDrb", MB_ICONWARNING);
        return 1;
    }
    return 0;
}

}  // namespace

int wmain(int argc, wchar_t* argv[]) {
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);

    // 双击启动（无参数）：转换同级目录 + data\ 下全部 .drb
    if (argc < 2) {
        return ConvertBatchInExeFolder();
    }

    // 命令行：DumpDrb <file.drb> [out.txt]
    const std::wstring outPath = (argc >= 3) ? argv[2] : ReplaceExt(argv[1], L".txt");
    std::wstring err;
    if (!ConvertOne(argv[1], outPath, &err)) {
        MessageBoxW(nullptr, err.c_str(), L"DumpDrb", MB_ICONERROR);
        return 1;
    }
    // 命令行成功：打到控制台，不弹框
    wprintf(L"已写入 UTF-8 文本: %s\n", outPath.c_str());
    return 0;
}
