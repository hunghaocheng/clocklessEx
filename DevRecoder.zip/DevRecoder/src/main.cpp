#include "DeviceRecorder.h"

#include <shellapi.h>

#include <memory>
#include <string>

namespace {

constexpr UINT_PTR kTimerPoll = 1;
constexpr UINT kTrayUid = 1;
constexpr UINT WM_TRAY = WM_APP + 1;
constexpr wchar_t kWindowClass[] = L"DevRecoderTrayWnd";
constexpr wchar_t kRunValueName[] = L"DevRecoder";

enum MenuId : UINT {
    IDM_TOGGLE = 1001,
    IDM_OPEN_DIR = 1002,
    IDM_AUTOSTART = 1003,
    IDM_EXIT = 1004,
};

struct AppState {
    std::unique_ptr<DeviceRecorder> recorder;
    NOTIFYICONDATAW nid{};
    bool trayAdded = false;
    bool autoStart = false;
    std::wstring dataDir;
    std::wstring currentFile;
    HINSTANCE instance = nullptr;
};

AppState* g_app = nullptr;

std::wstring ExePath() {
    wchar_t path[MAX_PATH]{};
    GetModuleFileNameW(nullptr, path, MAX_PATH);
    return path;
}

std::wstring ExeDir() {
    std::wstring path = ExePath();
    const size_t pos = path.find_last_of(L"\\/");
    if (pos == std::wstring::npos) return L".";
    return path.substr(0, pos);
}

bool EnsureDir(const std::wstring& dir) {
    if (CreateDirectoryW(dir.c_str(), nullptr) || GetLastError() == ERROR_ALREADY_EXISTS) {
        return true;
    }
    return false;
}

std::wstring MakeOutputPath(const std::wstring& dataDir) {
    SYSTEMTIME st{};
    GetLocalTime(&st);
    wchar_t buf[MAX_PATH]{};
    swprintf_s(buf, L"%s\\session_%04u%02u%02u_%02u%02u%02u.drb",
               dataDir.c_str(),
               st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
    return buf;
}

bool IsAutoStartEnabled() {
    HKEY key = nullptr;
    if (RegOpenKeyExW(HKEY_CURRENT_USER,
                      L"Software\\Microsoft\\Windows\\CurrentVersion\\Run",
                      0, KEY_READ, &key) != ERROR_SUCCESS) {
        return false;
    }
    wchar_t value[MAX_PATH]{};
    DWORD type = 0;
    DWORD size = sizeof(value);
    const LONG rc = RegQueryValueExW(key, kRunValueName, nullptr, &type,
                                     reinterpret_cast<LPBYTE>(value), &size);
    RegCloseKey(key);
    return rc == ERROR_SUCCESS && type == REG_SZ;
}

bool SetAutoStartEnabled(bool enable) {
    HKEY key = nullptr;
    if (RegOpenKeyExW(HKEY_CURRENT_USER,
                      L"Software\\Microsoft\\Windows\\CurrentVersion\\Run",
                      0, KEY_SET_VALUE | KEY_QUERY_VALUE, &key) != ERROR_SUCCESS) {
        return false;
    }

    LONG rc;
    if (enable) {
        std::wstring cmd = L"\"" + ExePath() + L"\" --autostart";
        rc = RegSetValueExW(key, kRunValueName, 0, REG_SZ,
                            reinterpret_cast<const BYTE*>(cmd.c_str()),
                            static_cast<DWORD>((cmd.size() + 1) * sizeof(wchar_t)));
    } else {
        rc = RegDeleteValueW(key, kRunValueName);
        if (rc == ERROR_FILE_NOT_FOUND) rc = ERROR_SUCCESS;
    }
    RegCloseKey(key);
    return rc == ERROR_SUCCESS;
}

void UpdateTrayTip(AppState& app) {
    if (!app.trayAdded) return;
    const bool on = app.recorder && app.recorder->IsRunning();
    const unsigned port = app.recorder ? app.recorder->BrowserPort() : 0;
    // 悬停提示不要用换行（部分系统不显示）；VERSION_4 需带 NIF_SHOWTIP
    if (on && port) {
        swprintf_s(app.nid.szTip, L"DevRecoder 采集中 | 事件:%llu | 桥:%u",
                   static_cast<unsigned long long>(app.recorder->EventCount()), port);
    } else if (on) {
        swprintf_s(app.nid.szTip, L"DevRecoder 采集中 | 事件:%llu",
                   static_cast<unsigned long long>(app.recorder->EventCount()));
    } else {
        swprintf_s(app.nid.szTip, L"DevRecoder 已暂停 | 事件:%llu",
                   app.recorder ? static_cast<unsigned long long>(app.recorder->EventCount()) : 0ull);
    }
    app.nid.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP | NIF_SHOWTIP;
    Shell_NotifyIconW(NIM_MODIFY, &app.nid);
}

bool StartRecording(AppState& app, HWND hwnd) {
    if (app.recorder && app.recorder->IsRunning()) return true;
    app.currentFile = MakeOutputPath(app.dataDir);
    app.recorder = std::make_unique<DeviceRecorder>(app.currentFile);
    if (!app.recorder->Start(hwnd)) {
        app.recorder.reset();
        MessageBoxW(hwnd, L"启动采集失败", L"DevRecoder", MB_ICONERROR);
        return false;
    }
    UpdateTrayTip(app);
    return true;
}

void StopRecording(AppState& app) {
    if (!app.recorder) return;
    app.recorder->Stop();
    UpdateTrayTip(app);
}

void ShowTrayMenu(HWND hwnd, AppState& app) {
    POINT pt{};
    GetCursorPos(&pt);
    HMENU menu = CreatePopupMenu();
    if (!menu) return;

    const bool running = app.recorder && app.recorder->IsRunning();

    AppendMenuW(menu, MF_STRING, IDM_TOGGLE, running ? L"暂停采集" : L"继续采集");
    AppendMenuW(menu, MF_STRING, IDM_OPEN_DIR, L"打开数据目录");
    AppendMenuW(menu, MF_STRING | (app.autoStart ? MF_CHECKED : 0),
                IDM_AUTOSTART, L"开机自启");
    AppendMenuW(menu, MF_SEPARATOR, 0, nullptr);
    AppendMenuW(menu, MF_STRING, IDM_EXIT, L"退出");

    // 托盘弹出菜单标准写法，否则可能点了「退出」收不到命令
    SetForegroundWindow(hwnd);
    const UINT cmd = TrackPopupMenu(
        menu,
        TPM_RIGHTBUTTON | TPM_RETURNCMD | TPM_NONOTIFY,
        pt.x, pt.y, 0, hwnd, nullptr);
    PostMessageW(hwnd, WM_NULL, 0, 0);
    DestroyMenu(menu);

    if (cmd) {
        SendMessageW(hwnd, WM_COMMAND, cmd, 0);
    }
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    AppState* app = g_app;

    switch (msg) {
        case WM_CREATE: {
            auto* cs = reinterpret_cast<CREATESTRUCTW*>(lParam);
            g_app = reinterpret_cast<AppState*>(cs->lpCreateParams);
            app = g_app;
            return 0;
        }
        case WM_INPUT:
            if (app && app->recorder) {
                app->recorder->HandleRawInput(reinterpret_cast<HRAWINPUT>(lParam));
            }
            return 0;
        case WM_TIMER:
            if (wParam == kTimerPoll && app && app->recorder && app->recorder->IsRunning()) {
                app->recorder->Poll();
                // 降低 tip 刷新频率：约每秒
                static int tick = 0;
                if (++tick % 60 == 0) UpdateTrayTip(*app);
            }
            return 0;
        case WM_TRAY: {
            // NOTIFYICON_VERSION_4：事件在 LOWORD(lParam)，HIWORD 是图标 ID
            const UINT trayEv = LOWORD(lParam);
            if (trayEv == WM_RBUTTONUP || trayEv == WM_RBUTTONDOWN ||
                trayEv == WM_CONTEXTMENU) {
                if (app) ShowTrayMenu(hwnd, *app);
            } else if (trayEv == WM_LBUTTONDBLCLK || trayEv == NIN_SELECT) {
                if (app) {
                    ShellExecuteW(hwnd, L"open", app->dataDir.c_str(), nullptr, nullptr,
                                  SW_SHOWNORMAL);
                }
            }
            return 0;
        }
        case WM_COMMAND:
            switch (LOWORD(wParam)) {
                case IDM_TOGGLE:
                    if (app->recorder && app->recorder->IsRunning()) {
                        StopRecording(*app);
                    } else {
                        StartRecording(*app, hwnd);
                    }
                    break;
                case IDM_OPEN_DIR:
                    ShellExecuteW(hwnd, L"open", app->dataDir.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
                    break;
                case IDM_AUTOSTART:
                    app->autoStart = !app->autoStart;
                    if (!SetAutoStartEnabled(app->autoStart)) {
                        MessageBoxW(hwnd, L"修改开机自启失败", L"DevRecoder", MB_ICONWARNING);
                        app->autoStart = IsAutoStartEnabled();
                    }
                    break;
                case IDM_EXIT:
                    DestroyWindow(hwnd);
                    break;
                default:
                    break;
            }
            return 0;
        case WM_DESTROY:
            if (app) {
                StopRecording(*app);
                if (app->trayAdded) {
                    Shell_NotifyIconW(NIM_DELETE, &app->nid);
                    app->trayAdded = false;
                }
            }
            KillTimer(hwnd, kTimerPoll);
            PostQuitMessage(0);
            return 0;
        default:
            return DefWindowProcW(hwnd, msg, wParam, lParam);
    }
}

}  // namespace

int APIENTRY wWinMain(HINSTANCE hInstance, HINSTANCE, LPWSTR, int) {
    // 单实例：已在托盘运行时静默退出，不弹提示框
    HANDLE mutex = CreateMutexW(nullptr, TRUE, L"Local\\DevRecoder_SingleInstance");
    if (!mutex || GetLastError() == ERROR_ALREADY_EXISTS) {
        return 0;
    }

    AppState app;
    app.instance = hInstance;
    app.dataDir = ExeDir() + L"\\data";
    EnsureDir(app.dataDir);
    app.autoStart = IsAutoStartEnabled();
    g_app = &app;

    WNDCLASSEXW wc{};
    wc.cbSize = sizeof(wc);
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInstance;
    wc.hIcon = LoadIconW(nullptr, IDI_APPLICATION);
    wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    wc.lpszClassName = kWindowClass;
    if (!RegisterClassExW(&wc)) return 1;

    HWND hwnd = CreateWindowExW(
        WS_EX_TOOLWINDOW, kWindowClass, L"DevRecoder",
        WS_POPUP, 0, 0, 0, 0,
        nullptr, nullptr, hInstance, &app);
    if (!hwnd) return 1;

    app.nid.cbSize = sizeof(app.nid);
    app.nid.hWnd = hwnd;
    app.nid.uID = kTrayUid;
    app.nid.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP | NIF_SHOWTIP;
    app.nid.uCallbackMessage = WM_TRAY;
    app.nid.hIcon = LoadIconW(nullptr, IDI_APPLICATION);
    wcscpy_s(app.nid.szTip, L"DevRecoder 启动中");
    if (Shell_NotifyIconW(NIM_ADD, &app.nid)) {
        app.trayAdded = true;
        app.nid.uVersion = NOTIFYICON_VERSION_4;
        Shell_NotifyIconW(NIM_SETVERSION, &app.nid);
        // SETVERSION 后重新带上 SHOWTIP，确保悬停可见
        app.nid.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP | NIF_SHOWTIP;
        Shell_NotifyIconW(NIM_MODIFY, &app.nid);
    }

    SetTimer(hwnd, kTimerPoll, 16, nullptr);

    if (!StartRecording(app, hwnd)) {
        DestroyWindow(hwnd);
        ReleaseMutex(mutex);
        CloseHandle(mutex);
        return 1;
    }

    MSG msg{};
    while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    ReleaseMutex(mutex);
    CloseHandle(mutex);
    return static_cast<int>(msg.wParam);
}
