const ENDPOINT = "http://127.0.0.1:17890/click";
const MAX_TABS_IN_SNAPSHOT = 30;

// 串行队列：每项带 resolve，便于知道 POST 是否成功
const queue = [];
let pumping = false;

const tabCache = new Map();
let snapshotTimer = null;
// 仅在 start 成功送达 DevRecoder 后为 true（失败可重试）
let sessionStarted = false;

function enqueue(payload) {
  return new Promise((resolve) => {
    queue.push({ payload, resolve });
    if (!pumping) {
      pumping = true;
      void pump();
    }
  });
}

async function pump() {
  while (queue.length > 0) {
    const { payload, resolve } = queue.shift();
    let ok = false;
    try {
      const res = await fetch(ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      ok = !!res && res.ok;
    } catch (_) {
      ok = false;
    }
    resolve(ok);
  }
  pumping = false;
}

function shortenUrl(url) {
  let u = String(url || "");
  const q = u.indexOf("?");
  if (q >= 0) u = u.slice(0, q);
  const h = u.indexOf("#");
  if (h >= 0) u = u.slice(0, h);
  return u.slice(0, 96);
}

function rememberTab(tab) {
  if (!tab || tab.id == null) return;
  const prev = tabCache.get(tab.id) || {};
  tabCache.set(tab.id, {
    url: tab.url || prev.url || "",
    title: tab.title || prev.title || "",
    active: !!tab.active
  });
}

function detectBrowser() {
  const ua = (navigator && navigator.userAgent) || "";
  if (/Edg\//.test(ua)) return "edge";
  return "chrome";
}

async function buildSnapshot() {
  let tabs = [];
  try {
    tabs = await chrome.tabs.query({});
  } catch (_) {
    tabs = [];
  }

  for (const t of tabs) rememberTab(t);

  const list = tabs.slice(0, MAX_TABS_IN_SNAPSHOT).map((t) => ({
    tab_id: t.id,
    active: !!t.active,
    url: shortenUrl(t.url || t.pendingUrl || ""),
    title: String(t.title || "").slice(0, 48)
  }));

  return {
    type: "browser_session",
    browser: detectBrowser(),
    tab_count: tabs.length,
    tabs: list
  };
}

async function sendSession(phase) {
  const snap = await buildSnapshot();
  snap.phase = phase;
  const ok = await enqueue(snap);
  if (phase === "start") sessionStarted = ok;
  if (phase === "end" && ok) sessionStarted = false;
  return ok;
}

function scheduleSnapshotUpdate() {
  if (snapshotTimer) clearTimeout(snapshotTimer);
  snapshotTimer = setTimeout(() => {
    snapshotTimer = null;
    void sendSession("update");
  }, 300);
}

function tabPayload(action, tabId, url, title) {
  return {
    type: "browser_tab",
    action,
    tab_id: tabId,
    url: String(url || "").slice(0, 500),
    page_title: String(title || "").slice(0, 120)
  };
}

/** 确保初始标签快照已写入；未成功则每次事件前重试 */
async function ensureSessionStart() {
  if (sessionStarted) return true;
  return sendSession("start");
}

// —— 页面点击 ——
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.type !== "devrecoder_click" || !msg.payload) {
    return;
  }
  if (!msg.payload.type) msg.payload.type = "browser_click";
  void ensureSessionStart().then(() => enqueue(msg.payload));
  sendResponse({ ok: true, queued: true });
  return false;
});

// —— 标签事件 ——
chrome.tabs.onCreated.addListener((tab) => {
  rememberTab(tab);
  void ensureSessionStart().then(() => {
    void enqueue(
      tabPayload("create", tab.id, tab.pendingUrl || tab.url || "", tab.title || "")
    );
    scheduleSnapshotUpdate();
  });
});

chrome.tabs.onRemoved.addListener((tabId) => {
  const cached = tabCache.get(tabId) || {};
  void ensureSessionStart().then(() => {
    void enqueue(tabPayload("close", tabId, cached.url || "", cached.title || ""));
    tabCache.delete(tabId);
    scheduleSnapshotUpdate();
  });
});

chrome.tabs.onActivated.addListener(async (info) => {
  let url = "";
  let title = "";
  try {
    const tab = await chrome.tabs.get(info.tabId);
    rememberTab(tab);
    url = tab.url || "";
    title = tab.title || "";
  } catch (_) {
    const cached = tabCache.get(info.tabId) || {};
    url = cached.url || "";
    title = cached.title || "";
  }
  await ensureSessionStart();
  void enqueue(tabPayload("active", info.tabId, url, title));
  scheduleSnapshotUpdate();
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.url || changeInfo.title || changeInfo.status === "complete") {
    rememberTab(tab);
    // 标签内容就绪时也尝试补发初始快照（DevRecoder 后开的情况）
    void ensureSessionStart().then(() => scheduleSnapshotUpdate());
  }
});

// 主导航完成 → 事务收尾信号（轻量近似 Request/Response）
if (chrome.webNavigation && chrome.webNavigation.onCompleted) {
  chrome.webNavigation.onCompleted.addListener((details) => {
    if (details.frameId !== 0) return;
    void ensureSessionStart().then(() => {
      void enqueue({
        type: "browser_nav",
        tab_id: details.tabId,
        url: String(details.url || "").slice(0, 500),
        page_title: ""
      });
    });
  });
}

chrome.runtime.onStartup.addListener(() => {
  sessionStarted = false;
  void sendSession("start");
});

chrome.runtime.onInstalled.addListener(() => {
  sessionStarted = false;
  void sendSession("start");
});

// service worker 唤起时尝试开会话；失败则保持 sessionStarted=false，后续事件会重试
void sendSession("start");
