// 捕获网页点击，提取 DOM 语义，交给 background 推送到本机 DevRecoder

function escIdent(s) {
  if (window.CSS && typeof CSS.escape === "function") return CSS.escape(s);
  return String(s).replace(/[^a-zA-Z0-9_-]/g, "\\$&");
}

function cssPath(el) {
  if (!el || el.nodeType !== 1) return "";
  const parts = [];
  let cur = el;
  for (let depth = 0; cur && cur.nodeType === 1 && depth < 6; depth++) {
    let part = cur.tagName.toLowerCase();
    if (cur.id) {
      part += "#" + escIdent(cur.id);
      parts.unshift(part);
      break;
    }
    const parent = cur.parentElement;
    if (parent) {
      const siblings = Array.from(parent.children).filter((c) => c.tagName === cur.tagName);
      if (siblings.length > 1) {
        part += `:nth-of-type(${siblings.indexOf(cur) + 1})`;
      }
    }
    parts.unshift(part);
    cur = parent;
  }
  return parts.join(">");
}

function isPasswordInput(el) {
  return el && el.tagName === "INPUT" && String(el.type || "").toLowerCase() === "password";
}

// 输入框：优先记录当前 value；密码框不记明文
function fieldText(el) {
  if (!el) return "";
  const tag = String(el.tagName || "").toUpperCase();

  if (tag === "INPUT" || tag === "TEXTAREA") {
    if (isPasswordInput(el)) return "[password]";
    const value = String(el.value || "").trim();
    if (value) return value.slice(0, 80);
    return String(
      el.getAttribute("placeholder") ||
        el.getAttribute("aria-label") ||
        el.getAttribute("name") ||
        ""
    )
      .trim()
      .slice(0, 80);
  }

  if (el.isContentEditable) {
    return String(el.innerText || "")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 80);
  }

  const aria = el.getAttribute && (el.getAttribute("aria-label") || el.getAttribute("title"));
  if (aria) return String(aria).trim().slice(0, 80);

  const t = (el.innerText || el.textContent || "").replace(/\s+/g, " ").trim();
  return t.slice(0, 80);
}

function elementTag(el) {
  const tag = String(el.tagName || "").toLowerCase();
  if (tag === "input") {
    const t = String(el.type || "text").toLowerCase();
    return ("input:" + t).slice(0, 24);
  }
  if (el.isContentEditable) return "contenteditable";
  return tag;
}

function pickTarget(raw) {
  if (!raw || !raw.closest) return raw;
  return (
    raw.closest(
      "input,textarea,select,a,button,summary,[contenteditable='true'],[role='textbox'],[role='searchbox'],[role='button'],[role='link'],[onclick]"
    ) || raw
  );
}

document.addEventListener(
  "click",
  (ev) => {
    try {
      const el = pickTarget(ev.target);
      if (!el || !el.tagName) return;

      const payload = {
        type: "browser_click",
        ts_ms: Date.now(),
        button: typeof ev.button === "number" ? ev.button : 0,
        url: String(location.href || "").slice(0, 500),
        page_title: String(document.title || "").slice(0, 120),
        tag: elementTag(el),
        id: String(el.id || el.getAttribute("name") || ""),
        class: String(el.className && typeof el.className === "string" ? el.className : ""),
        text: fieldText(el),
        href: String((el.href || (el.getAttribute && el.getAttribute("href"))) || ""),
        css_path: cssPath(el)
      };

      chrome.runtime.sendMessage({ type: "devrecoder_click", payload }, () => {
        void chrome.runtime.lastError;
      });
    } catch (_) {
      // 忽略页面异常，不影响点击
    }
  },
  true
);
