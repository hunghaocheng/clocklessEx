@echo off
setlocal
set "VSDEV=D:\Work\software\IDE\VS\VC\Auxiliary\Build\vcvars64.bat"
if not exist "%VSDEV%" (
  echo 未找到 VS: %VSDEV%
  exit /b 1
)
call "%VSDEV%"
cd /d "%~dp0"
if exist build rmdir /s /q build
cmake -S . -B build -G "NMake Makefiles" -DCMAKE_BUILD_TYPE=Release
if errorlevel 1 exit /b 1
cmake --build build
echo.
echo 可执行文件:
echo   %~dp0build\DevRecoder.exe   ^(托盘常驻^)
echo   %~dp0build\DumpDrb.exe
echo 数据目录: 与 exe 同级的 data\
echo 托盘菜单: 暂停/继续、打开目录、开机自启、退出
endlocal
